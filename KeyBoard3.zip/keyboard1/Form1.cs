﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace keyboard1
{
    public partial class Form1 : Form
    {
        private List<Panel> bars = new List<Panel>();
        private List<Timer> movementTimers = new List<Timer>();
        private Random random = new Random();
        private Timer hideTimer = new Timer { Interval = 1000 };
        private List<float> lastDestructionTimes = new List<float>() { 0f, 0f, 0f, 0f };
        private Stopwatch stopwatch = new Stopwatch();

        class Note
        {
            public Panel NotePanel { get; set; }
            public float CreationTime { get; set; }
        }

  
        public Form1()
        {
            InitializeComponent();

            // Bars를 리스트에 추가
            bars.Add(bar1);
            bars.Add(bar2);
            bars.Add(bar3);
            bars.Add(bar4);

    // Stopwatch 관리
            stopwatch.Start();

            // 각 바에 대한 타이머 설정
            foreach (var bar in bars)
            {
                for (int i = 0; i < 5; i++) // 각 바에 10개의 노트 생성
                {
                    int delay = random.Next(0, 20001); // 0초부터 10초 사이의 지연
                    Timer noteTimer = new Timer { Interval = delay };
                    noteTimer.Tick += (sender, e) => CreateNote(bar);
                    noteTimer.Start();
                }
            }
            this.KeyPreview = true; // 키 이벤트가 폼에서 먼저 캐치되도록 설정
            this.KeyDown += new KeyEventHandler(Form_KeyDown);
            hideTimer.Tick += HideTimer_Tick; // 타이머 이벤트 핸들러 추가
        }

        private void CreateNote(Panel bar)
        {
            Panel note = new Panel
            {
                Size = new Size(bar.Width, 5),
                Location = new Point(0, 0),
                BackColor = Color.Black
            };
            bar.Controls.Add(note);

            Timer moveTimer = new Timer { Interval = 150 }; // 1.5초 동안 이동
            moveTimer.Tick += (sender, e) => MoveNote(note, bar, moveTimer);
            moveTimer.Start();
        }

        private void MoveNote(Panel note, Panel bar, Timer moveTimer)
        {
            int moveStep = bar.Height / 10; // 10 steps to move from top to bottom
            note.Top += moveStep;

            if (note.Top >= bar.Height)
            {
                bar.Controls.Remove(note);
                moveTimer.Stop();
                moveTimer.Dispose();

                int barIndex = bars.IndexOf(bar);
                lastDestructionTimes[barIndex] = (float)stopwatch.Elapsed.TotalSeconds; // 소멸 시간 기록
            }
        }
        private void Form_KeyDown(object sender, KeyEventArgs e)
        {
            int barIndex = -1;
            switch (e.KeyCode)
            {
                case Keys.Z:
                    barIndex = 0;
                    break;
                case Keys.X:
                    barIndex = 1;
                    break;
                case Keys.C:
                    barIndex = 2;
                    break;
                case Keys.V:
                    barIndex = 3;
                    break;
            }

            if (barIndex != -1)
            {
                float currentTime = (float)stopwatch.Elapsed.TotalSeconds;
                float lastTime = lastDestructionTimes[barIndex];
                float diff = Math.Abs(currentTime - lastTime);

                if (diff <= 0.2)
                {
                    ShowMessage("OK");
                }
                else
                {
                    ShowMessage("Fail!");
                }
            }
        }
        private void ShowMessage(string message)
        {
            judgementLabel.Text = message;
            judgementLabel.Visible = true;
            hideTimer.Stop(); // 이전 타이머(있을 경우)를 중지하고
            hideTimer.Start(); // 타이머를 다시 시작합니다.
        }

        private void HideTimer_Tick(object sender, EventArgs e)
        {
            judgementLabel.Visible = false; // 라벨을 숨깁니다.
            hideTimer.Stop(); // 타이머를 중지합니다.
        }
    }
}
