﻿namespace keyboard1
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.bar1 = new System.Windows.Forms.Panel();
            this.bar2 = new System.Windows.Forms.Panel();
            this.bar3 = new System.Windows.Forms.Panel();
            this.bar4 = new System.Windows.Forms.Panel();
            this.judgementLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bar1
            // 
            this.bar1.BackColor = System.Drawing.SystemColors.Info;
            this.bar1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.bar1.Location = new System.Drawing.Point(70, 40);
            this.bar1.Name = "bar1";
            this.bar1.Size = new System.Drawing.Size(70, 300);
            this.bar1.TabIndex = 0;
            // 
            // bar2
            // 
            this.bar2.BackColor = System.Drawing.SystemColors.Info;
            this.bar2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.bar2.Location = new System.Drawing.Point(140, 40);
            this.bar2.Name = "bar2";
            this.bar2.Size = new System.Drawing.Size(70, 300);
            this.bar2.TabIndex = 1;
            // 
            // bar3
            // 
            this.bar3.BackColor = System.Drawing.SystemColors.Info;
            this.bar3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.bar3.Location = new System.Drawing.Point(210, 40);
            this.bar3.Name = "bar3";
            this.bar3.Size = new System.Drawing.Size(70, 300);
            this.bar3.TabIndex = 2;
            // 
            // bar4
            // 
            this.bar4.BackColor = System.Drawing.SystemColors.Info;
            this.bar4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.bar4.Location = new System.Drawing.Point(280, 40);
            this.bar4.Name = "bar4";
            this.bar4.Size = new System.Drawing.Size(70, 300);
            this.bar4.TabIndex = 3;
            // 
            // judgementLabel
            // 
            this.judgementLabel.AutoSize = true;
            this.judgementLabel.Location = new System.Drawing.Point(169, 377);
            this.judgementLabel.Name = "judgementLabel";
            this.judgementLabel.Size = new System.Drawing.Size(41, 18);
            this.judgementLabel.TabIndex = 4;
            this.judgementLabel.Text = "Wait";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 450);
            this.Controls.Add(this.judgementLabel);
            this.Controls.Add(this.bar4);
            this.Controls.Add(this.bar3);
            this.Controls.Add(this.bar2);
            this.Controls.Add(this.bar1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel bar1;
        private System.Windows.Forms.Panel bar2;
        private System.Windows.Forms.Panel bar3;
        private System.Windows.Forms.Panel bar4;
        private System.Windows.Forms.Label judgementLabel;
    }
}

